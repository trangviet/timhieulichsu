// DOM Elements
const searchInput = document.getElementById('searchInput');
const periodFilter = document.getElementById('periodFilter');
const timelineItems = document.querySelectorAll('.timeline-item');
const prevPageBtn = document.querySelector('.prev-page');
const nextPageBtn = document.querySelector('.next-page');
const pageNumber = document.querySelector('.page-number');

// State
let currentPage = 1;
const itemsPerPage = 5;
let filteredEvents = Array.from(timelineItems);

// Search and Filter Functions
function filterEvents() {
    const searchTerm = searchInput.value.toLowerCase();
    const selectedPeriod = periodFilter.value;

    filteredEvents = Array.from(timelineItems).filter(item => {
        const title = item.querySelector('h2').textContent.toLowerCase();
        const description = item.querySelector('p').textContent.toLowerCase();
        const year = item.querySelector('.year').textContent;

        const matchesSearch = title.includes(searchTerm) || description.includes(searchTerm);
        const matchesPeriod = !selectedPeriod || isInPeriod(year, selectedPeriod);

        return matchesSearch && matchesPeriod;
    });

    currentPage = 1;
    updateDisplay();
}

function isInPeriod(year, period) {
    const yearNum = parseInt(year);
    switch(period) {
        case 'hung-vuong':
            return yearNum >= -2879 && yearNum <= -258;
        case 'bac-thuoc':
            return yearNum >= -111 && yearNum <= 938;
        case 'phong-kien':
            return yearNum >= 938 && yearNum <= 1858;
        case 'phap-thuoc':
            return yearNum >= 1858 && yearNum <= 1945;
        case 'hien-dai':
            return yearNum >= 1945;
        default:
            return true;
    }
}

// Pagination Functions
function updateDisplay() {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const currentEvents = filteredEvents.slice(startIndex, endIndex);

    // Hide all items
    timelineItems.forEach(item => {
        item.style.display = 'none';
    });

    // Show current page items
    currentEvents.forEach(item => {
        item.style.display = 'flex';
        // Add animation class
        setTimeout(() => {
            item.classList.add('visible');
        }, 100);
    });

    // Update page number
    pageNumber.textContent = currentPage;

    // Update button states
    prevPageBtn.disabled = currentPage === 1;
    nextPageBtn.disabled = endIndex >= filteredEvents.length;
}

// Event Listeners
searchInput.addEventListener('input', filterEvents);
periodFilter.addEventListener('change', filterEvents);

prevPageBtn.addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        updateDisplay();
    }
});

nextPageBtn.addEventListener('click', () => {
    const maxPage = Math.ceil(filteredEvents.length / itemsPerPage);
    if (currentPage < maxPage) {
        currentPage++;
        updateDisplay();
    }
});

// Intersection Observer for animations
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, {
    threshold: 0.1
});

timelineItems.forEach(item => {
    observer.observe(item);
});

// Initialize
updateDisplay(); 