// DOM Elements
const searchInput = document.getElementById('searchInput');
const periodFilter = document.getElementById('periodFilter');
const figureCards = document.querySelectorAll('.figure-card');
const prevPageBtn = document.querySelector('.prev-page');
const nextPageBtn = document.querySelector('.next-page');
const pageNumber = document.querySelector('.page-number');

// State
let currentPage = 1;
const itemsPerPage = 6;
let filteredFigures = Array.from(figureCards);

// Search and Filter Functions
function filterFigures() {
    const searchTerm = searchInput.value.toLowerCase();
    const selectedPeriod = periodFilter.value;

    filteredFigures = Array.from(figureCards).filter(card => {
        const title = card.querySelector('h2').textContent.toLowerCase();
        const period = card.querySelector('.period').textContent.toLowerCase();
        const description = card.querySelector('p').textContent.toLowerCase();

        const matchesSearch = title.includes(searchTerm) || description.includes(searchTerm);
        const matchesPeriod = !selectedPeriod || period.includes(selectedPeriod.toLowerCase());

        return matchesSearch && matchesPeriod;
    });

    currentPage = 1;
    updateDisplay();
}

// Pagination Functions
function updateDisplay() {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const currentFigures = filteredFigures.slice(startIndex, endIndex);

    // Hide all cards
    figureCards.forEach(card => {
        card.style.display = 'none';
    });

    // Show current page cards
    currentFigures.forEach(card => {
        card.style.display = 'block';
        // Add animation class
        setTimeout(() => {
            card.classList.add('visible');
        }, 100);
    });

    // Update page number
    pageNumber.textContent = currentPage;

    // Update button states
    prevPageBtn.disabled = currentPage === 1;
    nextPageBtn.disabled = endIndex >= filteredFigures.length;
}

// Event Listeners
searchInput.addEventListener('input', filterFigures);
periodFilter.addEventListener('change', filterFigures);

prevPageBtn.addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        updateDisplay();
    }
});

nextPageBtn.addEventListener('click', () => {
    const maxPage = Math.ceil(filteredFigures.length / itemsPerPage);
    if (currentPage < maxPage) {
        currentPage++;
        updateDisplay();
    }
});

// Intersection Observer for animations
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, {
    threshold: 0.1
});

figureCards.forEach(card => {
    observer.observe(card);
});

// Initialize
updateDisplay(); 