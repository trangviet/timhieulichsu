// Danh sách các trang trong dòng lịch sử
const historicalPages = [
    {
        title: "Hồng Bàng - Văn Lang",
        url: "pages/dong-lich-su/hong-bang-van-lang.html",
        keywords: ["hồng bàng", "văn lang", "kinh dương vương", "lạc long quân", "vua hùng", "đông sơn", "trống đồng", 
                  "thời kỳ hồng bàng", "thời kỳ văn lang", "nước văn lang", "nước xích quỷ", "thời đại hùng vương",
                  "kinh dương", "lạc long", "âu cơ", "trống đồng đông sơn", "văn hóa đông sơn"]
    },
    {
        title: "Âu Lạc & Nam Việt",
        url: "pages/dong-lich-su/au-lac-nam-viet.html",
        keywords: ["âu lạc", "nam việt", "thục phán", "an dương vương", "cổ loa", "thành cổ loa", "nỏ thần",
                  "thời kỳ âu lạc", "thời kỳ nam việt", "nước âu lạc", "nước nam việt", "thục an dương vương",
                  "thành cổ", "nỏ thần kim quy", "mỵ châu", "trọng thủy"]
    },
    {
        title: "Bắc thuộc lần I",
        url: "pages/dong-lich-su/bac-thuoc-lan-1.html",
        keywords: ["bắc thuộc", "nhà hán", "hai bà trưng", "trưng trắc", "trưng nhị", "khởi nghĩa hai bà trưng",
                  "thời kỳ bắc thuộc", "bắc thuộc lần 1", "bắc thuộc lần thứ nhất", "trưng vương", "bà trưng",
                  "khởi nghĩa trưng vương", "nhà hán đô hộ", "thời hán thuộc"]
    },
    {
        title: "Trưng Nữ Vương",
        url: "pages/dong-lich-su/trung-nu-vuong.html",
        keywords: ["trưng nữ vương", "hai bà trưng", "trưng trắc", "trưng nhị", "khởi nghĩa hai bà trưng",
                  "trưng vương", "bà trưng", "khởi nghĩa trưng vương", "thời kỳ trưng vương", "nữ vương đầu tiên"]
    },
    {
        title: "Bắc thuộc lần II",
        url: "pages/dong-lich-su/bac-thuoc-lan-2.html",
        keywords: ["bắc thuộc lần 2", "bắc thuộc lần ii", "bắc thuộc lần thứ hai", "thời kỳ bắc thuộc lần 2",
                  "nhà hán đô hộ", "thời hán thuộc", "bắc thuộc"]
    },
    {
        title: "Nhà Lý & Nhà Triệu",
        url: "pages/dong-lich-su/nha-ly-nha-trieu.html",
        keywords: ["nhà lý", "nhà triệu", "lý bí", "lý nam đế", "triệu quang phục", "triệu việt vương",
                  "thời kỳ nhà lý", "thời kỳ nhà triệu", "vạn xuân", "nước vạn xuân", "lý bôn"]
    },
    {
        title: "Bắc thuộc lần III",
        url: "pages/dong-lich-su/bac-thuoc-lan-3.html",
        keywords: ["bắc thuộc lần 3", "bắc thuộc lần iii", "bắc thuộc lần thứ ba", "thời kỳ bắc thuộc lần 3",
                  "nhà hán đô hộ", "thời hán thuộc", "bắc thuộc"]
    },
    {
        title: "Thời kỳ xây nền tự chủ",
        url: "pages/dong-lich-su/thoi-ky-xay-nen-tu-chu.html",
        keywords: ["thời kỳ tự chủ", "xây nền tự chủ", "khởi nghĩa", "đấu tranh giành độc lập",
                  "thời kỳ độc lập", "tự chủ", "độc lập dân tộc"]
    },
    {
        title: "Nhà Ngô",
        url: "pages/dong-lich-su/nha-ngo.html",
        keywords: ["nhà ngô", "ngô quyền", "chiến thắng bạch đằng", "sông bạch đằng", "thời kỳ nhà ngô",
                  "triều ngô", "ngô vương", "đánh bại quân nam hán"]
    },
    {
        title: "Nhà Đinh",
        url: "pages/dong-lich-su/nha-dinh.html",
        keywords: ["nhà đinh", "đinh bộ lĩnh", "đinh tiên hoàng", "hoa lư", "kinh đô hoa lư",
                  "thời kỳ nhà đinh", "triều đinh", "đinh vương", "đinh hoàng"]
    },
    {
        title: "Nhà Tiền Lê",
        url: "pages/dong-lich-su/nha-tien-le.html",
        keywords: ["nhà tiền lê", "lê hoàn", "lê đại hành", "tiền lê", "thời kỳ tiền lê",
                  "triều tiền lê", "lê vương", "đánh bại quân tống"]
    },
    {
        title: "Nhà Lý",
        url: "pages/dong-lich-su/nha-ly.html",
        keywords: ["nhà lý", "lý thái tổ", "lý thái tông", "lý thánh tông", "lý nhân tông", "lý thường kiệt",
                  "thời kỳ nhà lý", "triều lý", "lý công uẩn", "thăng long", "kinh đô thăng long", "văn miếu",
                  "quốc tử giám", "chùa một cột", "lý thường kiệt", "nam quốc sơn hà"]
    },
    {
        title: "Nhà Trần",
        url: "pages/dong-lich-su/nha-tran.html",
        keywords: ["nhà trần", "trần thủ độ", "trần thái tông", "trần thánh tông", "trần nhân tông", "trần hưng đạo",
                  "thời kỳ nhà trần", "triều trần", "trần quốc tuấn", "hưng đạo vương", "bạch đằng giang",
                  "chiến thắng bạch đằng", "đánh bại quân nguyên", "ba lần đánh bại quân nguyên", "trần quốc toản",
                  "trần quang khải", "trần khánh dư", "trần bình trọng", "trần quốc tuấn"]
    },
    {
        title: "Nhà Hồ",
        url: "pages/dong-lich-su/nha-ho.html",
        keywords: ["nhà hồ", "hồ quý ly", "hồ hán thương", "tây đô", "kinh đô tây đô",
                  "thời kỳ nhà hồ", "triều hồ", "hồ vương", "cải cách hồ quý ly"]
    },
    {
        title: "Nhà Hậu Trần",
        url: "pages/dong-lich-su/nha-hau-tran.html",
        keywords: ["nhà hậu trần", "hậu trần", "giản định đế", "trùng quang đế", "đặng dung",
                  "thời kỳ hậu trần", "triều hậu trần", "khởi nghĩa hậu trần"]
    },
    {
        title: "Bắc thuộc lần IV",
        url: "pages/dong-lich-su/bac-thuoc-lan-4.html",
        keywords: ["bắc thuộc lần 4", "bắc thuộc lần iv", "bắc thuộc lần thứ tư", "thời kỳ bắc thuộc lần 4",
                  "nhà minh đô hộ", "thời minh thuộc", "bắc thuộc"]
    },
    {
        title: "Nhà Hậu Lê",
        url: "pages/dong-lich-su/nha-hau-le.html",
        keywords: ["nhà hậu lê", "hậu lê", "lê thái tổ", "lê thái tông", "lê thánh tông", "lê nhân tông",
                  "thời kỳ hậu lê", "triều hậu lê", "lê lợi", "lam sơn", "khởi nghĩa lam sơn",
                  "bình ngô đại cáo", "nguyễn trãi", "lê thánh tông"]
    },
    {
        title: "Nam Bắc Triều",
        url: "pages/dong-lich-su/nam-bac-trieu.html",
        keywords: ["nam bắc triều", "nhà mạc", "mạc đăng dung", "mạc thái tổ", "mạc thái tông",
                  "thời kỳ nam bắc triều", "triều mạc", "mạc vương", "nội chiến nam bắc"]
    },
    {
        title: "Trịnh Nguyễn Phân Tranh",
        url: "pages/dong-lich-su/trinh-nguyen-phan-tranh.html",
        keywords: ["trịnh nguyễn phân tranh", "chúa trịnh", "chúa nguyễn", "trịnh kiểm", "nguyễn hoàng",
                  "đàng ngoài", "đàng trong", "nội chiến trịnh nguyễn", "thời kỳ phân tranh"]
    },
    {
        title: "Nhà Tây Sơn",
        url: "pages/dong-lich-su/nha-tay-son.html",
        keywords: ["nhà tây sơn", "tây sơn", "nguyễn huệ", "quang trung", "nguyễn nhạc", "nguyễn lữ",
                  "thời kỳ tây sơn", "triều tây sơn", "khởi nghĩa tây sơn", "đánh bại quân thanh",
                  "chiến thắng kỷ dậu", "vua quang trung"]
    },
    {
        title: "Nhà Nguyễn",
        url: "pages/dong-lich-su/nha-nguyen.html",
        keywords: ["nhà nguyễn", "gia long", "minh mạng", "tự đức", "bảo đại", "huế", "kinh đô huế",
                  "thời kỳ nhà nguyễn", "triều nguyễn", "nguyễn ánh", "nguyễn phúc ánh", "cố đô huế",
                  "đại nam", "nước đại nam", "thời kỳ phong kiến cuối cùng"]
    },
    {
        title: "Pháp Thuộc",
        url: "pages/dong-lich-su/phap-thuoc.html",
        keywords: ["pháp thuộc", "thời kỳ pháp thuộc", "thực dân pháp", "đô hộ pháp", "thời thuộc địa",
                  "phong trào cần vương", "văn thân", "sĩ phu yêu nước", "phong trào đông du",
                  "phan bội châu", "phan chu trinh", "nguyễn thái học"]
    },
    {
        title: "Việt Nam Dân Chủ Cộng Hoà",
        url: "pages/dong-lich-su/viet-nam-dan-chu-cong-hoa.html",
        keywords: ["việt nam dân chủ cộng hòa", "hồ chí minh", "cách mạng tháng tám", "tuyên ngôn độc lập",
                  "kháng chiến chống pháp", "điện biên phủ", "hiệp định genève", "thời kỳ dân chủ cộng hòa"]
    },
    {
        title: "Cộng hoà xã hội chủ nghĩa Việt Nam",
        url: "pages/dong-lich-su/cong-hoa-xa-hoi-chu-nghia-viet-nam.html",
        keywords: ["cộng hòa xã hội chủ nghĩa việt nam", "thời kỳ hiện đại", "đổi mới", "công nghiệp hóa",
                  "hiện đại hóa", "hội nhập quốc tế", "phát triển kinh tế", "thời kỳ đổi mới"]
    }
];

// Tạo container cho gợi ý
function createSuggestionsContainer() {
    const container = document.createElement('div');
    container.className = 'search-suggestions';
    container.style.display = 'none';
    return container;
}

// Tạo gợi ý
function createSuggestionItem(page) {
    const div = document.createElement('div');
    div.className = 'suggestion-item';
    div.innerHTML = `
        <div class="suggestion-title">${page.title}</div>
        <div class="suggestion-keywords">${page.keywords.slice(0, 3).join(', ')}...</div>
    `;
    div.addEventListener('click', () => {
        window.location.href = page.url;
    });
    return div;
}

// Tính điểm phù hợp cho kết quả tìm kiếm
function calculateRelevanceScore(page, searchTerm) {
    const searchTermLower = searchTerm.toLowerCase();
    let score = 0;

    // Kiểm tra tiêu đề
    if (page.title.toLowerCase().includes(searchTermLower)) {
        score += 100;
    }

    // Kiểm tra từ khóa
    page.keywords.forEach(keyword => {
        if (keyword.toLowerCase().includes(searchTermLower)) {
            score += 50;
            // Thêm điểm nếu từ khóa bắt đầu bằng từ tìm kiếm
            if (keyword.toLowerCase().startsWith(searchTermLower)) {
                score += 25;
            }
        }
    });

    return score;
}

// Tìm kiếm và hiển thị gợi ý
function searchAndShowSuggestions(searchTerm) {
    const suggestionsContainer = document.querySelector('.search-suggestions');
    suggestionsContainer.innerHTML = '';
    
    if (searchTerm.length < 1) { // Giảm độ dài tối thiểu xuống 1 ký tự
        suggestionsContainer.style.display = 'none';
        return;
    }

    // Tìm kiếm và sắp xếp kết quả theo độ phù hợp
    const results = historicalPages
        .map(page => ({
            ...page,
            score: calculateRelevanceScore(page, searchTerm)
        }))
        .filter(result => result.score > 0)
        .sort((a, b) => b.score - a.score);

    if (results.length > 0) {
        results.forEach(page => {
            suggestionsContainer.appendChild(createSuggestionItem(page));
        });
        suggestionsContainer.style.display = 'block';
    } else {
        suggestionsContainer.style.display = 'none';
    }
}

// Khởi tạo chức năng tìm kiếm
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.querySelector('input[type="text"]');
    const searchContainer = searchInput.parentElement;
    
    // Thêm container gợi ý
    const suggestionsContainer = createSuggestionsContainer();
    searchContainer.appendChild(suggestionsContainer);

    // Xử lý sự kiện input với debounce
    let debounceTimer;
    searchInput.addEventListener('input', function(e) {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            searchAndShowSuggestions(e.target.value);
        }, 100); // Giảm thời gian chờ xuống 100ms
    });

    // Ẩn gợi ý khi click ra ngoài
    document.addEventListener('click', function(e) {
        if (!searchContainer.contains(e.target)) {
            suggestionsContainer.style.display = 'none';
        }
    });

    // Xử lý phím Enter
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const firstSuggestion = document.querySelector('.suggestion-item');
            if (firstSuggestion) {
                firstSuggestion.click();
            }
        }
    });
}); 