document.addEventListener('DOMContentLoaded', function() {
    // Initialize timeline animations
    initTimelineAnimations();
    
    // Initialize smooth scrolling for timeline navigation
    initSmoothScroll();
    
    // Initialize active state for timeline sections
    initActiveSections();
});

function initTimelineAnimations() {
    // Create Intersection Observer for timeline items
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });

    // Observe all timeline items
    document.querySelectorAll('.timeline-item').forEach(item => {
        observer.observe(item);
    });

    // Observe section titles
    document.querySelectorAll('.section-title').forEach(title => {
        observer.observe(title);
    });
}

function initSmoothScroll() {
    // Get all timeline navigation links
    const navLinks = document.querySelectorAll('.sidebar-widget a[href^="#"]');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Get target section
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                // Calculate offset for fixed header
                const headerHeight = document.querySelector('.navbar').offsetHeight;
                const targetPosition = targetSection.offsetTop - headerHeight - 20;
                
                // Smooth scroll to target
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
                // Update active state
                updateActiveLink(this);
            }
        });
    });
}

function initActiveSections() {
    // Create Intersection Observer for sections
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Get section id
                const sectionId = entry.target.getAttribute('id');
                
                // Update active link
                const activeLink = document.querySelector(`.sidebar-widget a[href="#${sectionId}"]`);
                if (activeLink) {
                    updateActiveLink(activeLink);
                }
            }
        });
    }, {
        threshold: 0.5,
        rootMargin: '-100px 0px -50% 0px'
    });

    // Observe all timeline sections
    document.querySelectorAll('.timeline-section').forEach(section => {
        observer.observe(section);
    });
}

function updateActiveLink(activeLink) {
    // Remove active class from all links
    document.querySelectorAll('.sidebar-widget a').forEach(link => {
        link.classList.remove('active');
    });
    
    // Add active class to clicked link
    activeLink.classList.add('active');
}

// Add scroll progress indicator
function initScrollProgress() {
    const progressBar = document.createElement('div');
    progressBar.className = 'scroll-progress';
    document.body.appendChild(progressBar);

    window.addEventListener('scroll', () => {
        const windowHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const progress = (window.scrollY / windowHeight) * 100;
        progressBar.style.width = `${progress}%`;
    });
}

// Initialize scroll progress
initScrollProgress();

// Add hover effect for timeline items
document.querySelectorAll('.timeline-item').forEach(item => {
    item.addEventListener('mouseenter', function() {
        this.classList.add('hover');
    });
    
    item.addEventListener('mouseleave', function() {
        this.classList.remove('hover');
    });
});

// Add click event for read more links
document.querySelectorAll('.read-more').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        const content = this.previousElementSibling;
        
        if (content.style.maxHeight) {
            content.style.maxHeight = null;
            this.textContent = 'Đọc tiếp';
        } else {
            content.style.maxHeight = content.scrollHeight + 'px';
            this.textContent = 'Thu gọn';
        }
    });
}); 